# yt music down

[![PyPI - Version](https://img.shields.io/pypi/v/yt-music-down.svg)](https://pypi.org/project/yt-music-down)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/yt-music-down.svg)](https://pypi.org/project/yt-music-down)

-----

## Table of Contents

- [Installation](#installation)
- [License](#license)

## Installation

```console
pip install yt-music-down
```

## License

`yt-music-down` is distributed under the terms of the [MIT](https://spdx.org/licenses/MIT.html) license.
